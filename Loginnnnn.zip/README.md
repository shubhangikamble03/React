# Getting Started with user-login app

User Login App is provided to understand useEffect and useReducer hook.

## Follow below advice

-	Follow trainer for code along activity.
-	As per the concept discussed in training this app will be created. 
-	This is just the initial app. You are adviced to understand the concepts on this app. 
-	In case you want to practice on your own code. You can do, but in case if doubts comes, then it can not be resolved.
-	Here the focus of learning is React Specific concepts, not UI.

