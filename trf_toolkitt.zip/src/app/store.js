import { configureStore } from "@reduxjs/toolkit";

import trainingInitiatiorSectionSlice from "../features/trainingInitiarors/trainingInitiatiorSectionSlice";
import registrationSlice from "../features/registration/registrationSlice";

export const store = configureStore({
  reducer: {
    trf: trainingInitiatiorSectionSlice,
    registration:registrationSlice,
  },
});
