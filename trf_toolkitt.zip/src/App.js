import React, { useEffect, useState } from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import TrainingInitiatiorSection from "./pages/TrainingInitiatorsSection";

import MainHeader from "./MainHeader/MainHeader";
import Login from "./Login/Login";
import Home from "./Home/Home";
import ImportExcelData from "./pages/ImportExcelData";
import UpdateTrainingSec from "./pages/UpdateTrainingSec";
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const loginHandler = (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    localStorage.setItem("isLoggedIn", "1");
    setIsLoggedIn(true);
  };

  //Run only onces hence depedency array is blank
  useEffect(() => {
    const userLoggedInStauts = localStorage.getItem("isLoggedIn");
    if (userLoggedInStauts === "1") {
      setIsLoggedIn(true);
    }
  }, []);

  //If we write userLoggedInStauts code out of useEffect It goes in infinite loop
  const logoutHandler = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
  };
  return (
    <React.Fragment>
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      <div className="App">
        <Routes>
          <Route
            path="/"
            element={!isLoggedIn && <Login onLogin={loginHandler} />}
            exact
          />
          <Route
            path="/home"
            element={isLoggedIn && <Home onLogout={logoutHandler} />}
            exact
          />

          {/* <Route path="/" element={<TrfList />} /> */}
          <Route
            path="/add-trf"
            element={<TrainingInitiatiorSection />}
          >
            
          </Route>
          <Route
            path="/add-employee-excelsheet"
            element={<ImportExcelData />}
            exact
          ></Route>
          <Route path="/update-tri/:id" element={<UpdateTrainingSec />}></Route>



    

          {/* <Route path="/add-car" element={<AddCar />}></Route>
          <Route path="/edit-car/:id" element={<EditCar />}></Route>*/}
        </Routes>
      </div>
    </React.Fragment>
  );
}

export default App;
