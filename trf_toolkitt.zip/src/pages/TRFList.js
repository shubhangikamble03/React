import React, { useEffect } from "react";
import "./TRFList.css";
// import Dates from "./Dates";

import {
 
  getAllTRF,
  fetchAllTrainingInitiators,
} from "../features/trainingInitiarors/trainingInitiatiorSectionSlice";
import { useDispatch, useSelector } from "react-redux";

import { useNavigate } from "react-router-dom";

const TRFList = () => {
  const navigate = useNavigate();
  const allTrf = useSelector(getAllTRF);
 
  const dispatch = useDispatch();
  // const { trfData } = useContext(TrfContext);

  //console.log(trfData);
  useEffect(() => {
    if (allTrf.length === 0) {
      dispatch(fetchAllTrainingInitiators());
    }
  }, [dispatch]);

  return (
    <div>
      <h1 className="trf_h1">TRF LIST</h1>
      <div className="trf">
        <div className="tp">
          <table className="td">
            <thead className="th">
              <tr>
                <th>Id</th>
                <th>Training Title</th>
                <th>Initiated from</th>
                <th>Training Type</th>
                <th>Project Name</th>
                <th>Resource Type</th>
                <th>Duration(In Days)</th>
                <th>No of participants</th>
                <th>Skills to be imparted</th>
                <th>Training Start Date(dd-mm-yyyy)</th>
                <th>Training End Date(dd-mm-yyyy)</th>
                <th>Purpose of training</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody className="td">
              {allTrf.map((val, key) => {
                return (
                  <tr key={key}>
                    <td>{key + 1}</td>
                    <td>{val.trainingTitle}</td>
                    <td>{val.intiatedFrom}</td>
                    <td>{val.trainingType}</td>
                    <td>{val.projectName}</td>
                    <td>{val.resourceType}</td>
                    <td>{val.duration}</td>
                    <td>{val.count}</td>
                    <td>{val.skillsImparted}</td>
                    <td> {val.startDate} </td>
                    <td> {val.endDate} </td>
                    <td>{val.purposeOfTraining}</td>
                    <td>
                      <button
                        variant="dark"
                        type="button"
                        className="button1"
                        onClick={() => {
                           
                          navigate(`/update-tri/${val.id}`);
                        }}
                      >
                        Edit
                      </button>
                      <button type="button" class="button3">DEL</button>
                    
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* </Card> */}
      </div>
    </div>
  );
};

export default TRFList;
