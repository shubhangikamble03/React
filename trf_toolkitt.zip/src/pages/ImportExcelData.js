import React, { useState } from "react";
import { utils, read } from "xlsx";
import { Link } from "react-router-dom";


const ImportExcelData = () => {
  const [excelData, setExcelData] = useState([]);

  const fileType = [
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ];

  const handleChange = (e) => {
    const selectFile = e.target.files[0];

    if (selectFile) {
      if (selectFile && fileType.includes(selectFile.type)) {
        let reader = new FileReader();

        reader.onload = (e) => {
          const workbook = read(e.target.result);

          console.log(workbook.Sheets.name);

          const sheet = workbook.SheetNames;

          console.log(sheet);

          if (sheet.length) {
            const data = utils.sheet_to_json(workbook.Sheets[sheet[0]]);

            setExcelData(data);
          }
        };

        reader.readAsArrayBuffer(selectFile);
      } else {
        console.log("Only accept excel file");
      }

      console.log(selectFile.type);
    }
  };

  return (
    <div className="excel">
      {" "}
      ImportExcelData
      <div>
        <Link to="/add-trf">
        {/* <Button>BACK</Button> */}
        <button >back</button>
        </Link>
    
          <div>
            <input  type="file" onChange={handleChange} />
          </div>
          <div>
            <table className="table">
              <thead className="th">
                

                <tr>
                  <th>SR.ID</th>
                  <th>EmpID</th>
                  <th>Name</th>
                  <th>Trainer</th>
                  <th>Email</th>

                  <th>Experience(in Years)</th>
                  <th>Grade(E1/E2/E3)</th>
                  <th>Current Skills</th>
                  <th>CurrentAllocation</th>

                  <th>Project</th>
                  <th>CurrentLocation</th>

                  <th>Upgraded_Skill_Set</th>
                  <th>Batch</th>
                  <th>Mentor</th>
                </tr>
              </thead>

              <tbody className="td">
                {excelData.length ? (
                  excelData.map((info) => (
                    <tr>
                      <td>{info.No}</td>
                      <td>{info.EmpID}</td>
                      <td>{info.Name}</td>
                      <td>{info.Trainer}</td>
                      <td>{info.Email}</td>

                      <td>{info.Experience}</td>
                      <td>{info.Grade}</td>
                      <td>{info.CurrentSkill}</td>
                      <td>{info.CurrentLocation}</td>

                      <td>{info.Project}</td>
                      <td>{info.CurrentLocation}</td>

                      <td>{info.UpgradedSkillSet} </td>

                      <td>{info.Batch}</td>

                      <td>{info.Mentor}</td>
                    </tr>
                  ))
                ) : (
                  <tr>No data</tr>
                )}
              </tbody>
            </table>
        
        </div>

        {/* <div>
        <input type="file" accept=".xlsx" onChange={handleFileChange} />
        <button onClick={handleUpload}>Upload</button>
      </div> */}
      </div>
    </div>
  );
};

export default ImportExcelData;
