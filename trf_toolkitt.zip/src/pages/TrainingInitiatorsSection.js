import React, { useEffect, useState } from "react";

import "./TrainingInitiatiorSection.css";

import { Link, Outlet } from "react-router-dom";

import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  getLoading,
  addTRF,

} from "../features/trainingInitiarors/trainingInitiatiorSectionSlice";
import Button from "../UI/Button/Button";
import ErrorModal from "../UI/Error/ErrorModal";

import Swal from "sweetalert2";
const TrainingInitiatiorSection = () => {

  const disptach = useDispatch();
  const navigate = useNavigate();


  const [date, setDate] = useState(new Date());

  useEffect(() => {
    var timer = setInterval(() => setDate(new Date()), 1000);
    return function cleanup() {
      clearInterval(timer);
    };
  });

  const [userInput, setUserInput] = useState({
    enteredTrainingTitle: "",

    enteredIntiatedFrom: "",

    enteredTrainingType: "",

    enteredProjectName: "",

    eresourceType: "",

    enteredDuration: 0,

    enteredcount: 0,

    enterskillsImparted: "",

    enteredPurposeOfTraining: "",

    enterstartDate: date.toLocaleDateString(),

    enteredEndDate: date.toLocaleDateString(),
  });

  // const importExcelDataHandler = () => {
  //   navigate("/add-employee-excelsheet");
  // };

  const [error, setError] = useState();

  const trainingChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredTrainingTitle: event.target.value };
    });
  };

  const InitiatedChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredIntiatedFrom: event.target.value };
    });
  };

  const trainingTypeChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredTrainingType: event.target.value };
    });
  };

  const projectNameChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredProjectName: event.target.value };
    });
  };

  const resourceTypeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, eresourceType: event.target.value };
    });
  };

  //resourceType

  const durationChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredDuration: event.target.value };
    });
  };

  const countHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredcount: event.target.value };
    });
  };

  const enteredPurposeOfTrainingChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredPurposeOfTraining: event.target.value };
    });
  };

  //skillsImparted

  const enterskillsImpartedHandle = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enterskillsImparted: event.target.value };
    });
  };

  const enterstartDateHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enterstartDate: event.target.value };
    });
  };

  const enteredEndDateChangeHandler = (event) => {
    setUserInput((prevState) => {
      return { ...prevState, enteredEndDate: event.target.value };
    });
  };

  const showAlert = () => {
    Swal.fire({
      title: "Success",
      text: "Data Inserted successful",
      icon: "success",
      confirmButtonText: "OK",
    }).then(function () {
      // Redirect the user
      navigate("/home");
    });
  };

  const trfFormSumbitHandler = (event) => {
    event.preventDefault();

    if (
      userInput.enteredTrainingTitle.trim().length === 0 ||
      userInput.enteredIntiatedFrom.trim().length === 0 ||
      userInput.enteredTrainingType.trim().length === 0 ||
      userInput.enteredProjectName.trim().length === 0 ||
      userInput.eresourceType.trim().length === 0 ||
      userInput.enterskillsImparted.trim().length === 0 ||
      userInput.enteredPurposeOfTraining.trim().length === 0
    ) {
      setError({
        title: "Invalid input",

        message: "please enter valid input",
      });

      return;
    }

    if (+userInput.enteredDuration < 1 || +userInput.enteredcount < 1) {
      setError({
        title: "Invalid Input",

        message: "Please Enter a Valid input greater then 0",
      });

      return;
    }

    const newTrf = {
      //id: trfData.length + 1,
      trainingTitle: userInput.enteredTrainingTitle,

      intiatedFrom: userInput.enteredIntiatedFrom,

      trainingType: userInput.enteredTrainingType,

      projectName: userInput.enteredProjectName,

      resourceType: userInput.eresourceType,

      duration: userInput.enteredDuration,

      count: userInput.enteredcount,

      skillsImparted: userInput.enterskillsImparted,

      purposeOfTraining: userInput.enteredPurposeOfTraining,

      startDate: userInput.enterstartDate,

      endDate: userInput.enteredEndDate,
    };

   

    disptach(addTRF(newTrf)).then(() => {
   
      showAlert();
    });
    // setUserInput({
    //   enteredTrainingTitle: "",

    //   enteredIntiatedFrom: "",

    //   enteredTrainingType: "",

    //   enteredProjectName: "",

    //   eresourceType: "",

    //   enteredDuration: 0,

    //   enteredcount: 0,

    //   enterskillsImparted: "",

    //   enteredPurposeOfTraining: "",

    //   enterstartDate: "",

    //   enteredEndDate: "",
    // });
  };

  const errorHadler = () => {
    setError(null);
  };

  return (
    <React.Fragment>
      <div>
        <div className="trfmain">
          {error && (
            <ErrorModal
              onConfirm={errorHadler}
              title={error.title}
              message={error.message}
            />
          )}

          {/* <Card> */}
          {/* <div> */}

          <h2 className="h2"> TraningRequestIntiator Section</h2>

          <br />

          <form onSubmit={trfFormSumbitHandler}>
            <div className="new__controls">
              <div className="new__control">
                <label htmlFor="traningTitle">Training Title :</label>

                <input
                  type="text"
                  name="trainingTitle"
                  id="TrainingTitle"
                  onChange={trainingChangeHandler}
                  value={userInput.enteredTrainingTitle}
                />
              </div>

              <div className="new__control">
                <label>Initiated From :</label>

                <input
                  type="text"
                  name="initiatedFrom"
                  id="intiatedFrom"
                  onChange={InitiatedChangeHandler}
                  value={userInput.enteredIntiatedFrom}
                />
              </div>

              <div className="new__control">
                <label>Training Type :</label>

                <select
                  // type="text"

                  name="trainingType"
                  id="trainingType"
                  onChange={trainingTypeChangeHandler}
                  value={userInput.enteredTrainingType}
                >
                  <option value=""> Select Option</option>

                  <option value="FRW(Future Ready Workforce)">
                    FRW(Future Ready Workforce)
                  </option>

                  <option value="DRWF(Digital Ready Workforce)">
                    DRWF(Digital Ready Workforce)
                  </option>

                  <option value="On Demand">On Demand</option>

                  <option value="Project Specific"> Project Specific</option>
                </select>
              </div>

              <div className="new__control">
                <label>Project Name :</label>

                <input
                  type="text"
                  name="projectName"
                  id="ProjectName"
                  onChange={projectNameChangeHandler}
                  value={userInput.enteredProjectName}
                />
              </div>

              <div className="new__control">
                <label>Resource Type :</label>

                <select
                  type="text"
                  name="resourceType"
                  id="resourceType"
                  onChange={resourceTypeHandler}
                  value={userInput.eresourceType}
                >
                  <option value=""> Select Option</option>

                  <option value="DRWF(Digital Ready Workforce)">
                    DRWF(Digital Ready Workforce)
                  </option>

                  <option value="Fresher">Fresher</option>

                  <option value="Lateral"> Lateral</option>

                  <option value="CDAC"> CDAC</option>

                  <option value="Interns"> Interns</option>

                  <option value="On Bench"> On Bench</option>
                </select>
              </div>

              <div className="new__control">
                <label>Duration :</label>

                <input
                  type="number"
                  name="duration"
                  id="Duration"
                  onChange={durationChangeHandler}
                  value={userInput.enteredDuration}
                  required
                />
              </div>

              <div className="new__control">
                <label>No of Participants : </label>

                <input
                  type="number"
                  name="count"
                  id="count"
                  onChange={countHandler}
                  value={userInput.enteredcount}
                  required
                />
              </div>

              <div className="new__control">
                <label>Skill To Be Imparted : </label>

                <input
                  type="text"
                  name="skillsImparted"
                  id="skillsImparted"
                  onChange={enterskillsImpartedHandle}
                  value={userInput.enterskillsImparted}
                />
              </div>

              <div className="new__control">
                <label>Purpose of Training :</label>

                <input
                  type="text"
                  name="trainingTitle"
                  id="PurposeOfTraining"
                  onChange={enteredPurposeOfTrainingChangeHandler}
                  value={userInput.enteredPurposeOfTraining}
                />
              </div>

              <div className="new__control">
                <label>Training Start Date : &nbsp; </label>

                <input
                  type="date"
                  name="startDate"
                  id="startDate"
                  onChange={enterstartDateHandler}
                  value={userInput.enterstartDate}
                  required
                />
              </div>

              <div className="new__control">
                <label>TrainingEnd Date : &nbsp;</label>

                <input
                  type="date"
                  name="endDate"
                  id="EndDate"
                  onChange={enteredEndDateChangeHandler}
                  value={userInput.enteredEndDate}
                  required
                />
              </div>

              <div>
                <Button type="submit">NEXT</Button>
                {/* <button type="submit">Next</button> &nbsp; */}
                <div></div>
              </div>
              <div>
                <Link to="/add-employee-excelsheet">
                  <Button type="submit">Upload Excel</Button>
                  {/* Hiiiii */}
                </Link>
                <Outlet/>
              </div>
              {/* <div>
                <button>ADD</button>
              </div> */}
            </div>
          </form>

          {/* /add-employee-excelsheet */}

          <div>
            {/* <input
              type="file"
              accept=".xlsx, .xls"
              onChange={handleFileChange}
            /> */}

            {/* onClick={showTrfData} */}

            {/*

            <Button type="submit"  onClick={() => {

           

           handleUpload();

           handleNavigation();

        }}>Upload

        </Button>  */}

            {/* <button onClick={handleUpload}>Upload</button> */}
          </div>

          <br />
          {/* </Card> */}

          {/* </div> */}
        </div>

        {/* <TRFList trf={trf} /> */}
      </div>
    </React.Fragment>
  );
};

export default TrainingInitiatiorSection;
