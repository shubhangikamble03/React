//training-initiators-list
import axios from "axios";

const { createSlice, createAsyncThunk } = require("@reduxjs/toolkit");

export const fetchAllTrainingInitiators = createAsyncThunk(
  "trf/training-initiators-list",
  async () => {
    const response = await axios.get("http://localhost:4000/trf");
    return response.data;
  }
);

export const addTRF = createAsyncThunk("trf/createAPI", async (payload) => {
  const response = await axios.post("http://localhost:4000/trf", payload);
  return response.data;
});

export const updateTri = createAsyncThunk("trf/updateAPI", async (payload) => {
  const response = await axios.put(
    `http://localhost:4000/trf/${payload.id}`,
    payload
  );
  return response.data;
});


const initialState = {
    trfData: [],
    loading: "idle",
  };


const trainingInitiatiorSectionSlice = createSlice({
  name: "trf",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchAllTrainingInitiators.pending, (state, action) => {
      state.loading = "pending";
    });
    builder.addCase(fetchAllTrainingInitiators.fulfilled, (state, action) => {
      state.loading = "idle";
      state.trfData = action.payload;
    });
    builder.addCase(addTRF.pending, (state, action) => {
      state.loading = "pending";
    });
    builder.addCase(addTRF.fulfilled, (state, action) => {
      state.loading = "idle";
      state.trfData.unshift(action.payload);
    });
    builder.addCase(updateTri.pending, (state) => {
      state.loading = "pending";
    });
    builder.addCase(updateTri.fulfilled, (state, action) => {
      state.loading = "idle";
      state.trfData = state.trfData.filter((_) => _.id !== action.payload.id);
      state.trfData.unshift(action.payload);
    });
   
  },
});

export const getAllTRF = (state) => state.trf.trfData;
export const getLoading = (state) => state.trf.loading;
export const getTRIById = (id) => {
  return (state) => state.trf.trfData.filter((_) =>  _.id === id)[0];
};
export default trainingInitiatiorSectionSlice.reducer;

